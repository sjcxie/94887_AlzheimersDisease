# Original Data
data = read.csv("df_log_scaled.csv", header=TRUE)
# data for EDA plots
data_full = read.csv("df_ohe_corrected.csv", header=TRUE)
data_eda = read.csv("adni_label_wind.csv", header=TRUE)
new_data_raw = read.csv("new_points.csv", header=TRUE)

# Model
load("RandomForest_m6.rda")    # Load saved model RF6
load("RandomForest_m12.rda")    # Load saved model RF12
load("RandomForest_m24.rda")    # Load saved model RF24

# helper to convert from eda data back to categorical
transform_from_ohe <- function(df) {
  data_with_cat_summary = df %>% 
    mutate(APOE4_Allele = ifelse(APOE4 == 0, '0 Allele',
                                 ifelse(APOE4 == 1, '1 Allele', '2 Allele'))) %>%
    mutate(Gender = ifelse(PTGENDER_Female == 1, "F", "M")) %>%
    mutate(Ethnicity = ifelse(PTETHCAT_Not.Hisp.Latino == 1, "Not Hispanic", "Hispanic")) %>%
    mutate(Race = ifelse(PTRACCAT_White == 1, "White",
                         ifelse(PTRACCAT_Am.Indian.Alaskan == 1, "Native American",
                                ifelse(PTRACCAT_Asian == 1, "Asian",
                                       ifelse(PTRACCAT_Black == 1, "Black",
                                              ifelse(PTRACCAT_Hawaiian.Other.PI == 1, "Hawaiian/PI", "Multi-racial")))))) %>%
    mutate(Marital_Status = ifelse(PTMARRY_Never.married == 1, "Never Married",
                                   ifelse(PTMARRY_Married == 1, "Married",
                                          ifelse(PTMARRY_Widowed == 1, "Widowed", "Divorced")))) %>%
    mutate(AD_Transition_Time = ifelse(tran_1to2_m6 == 1, 'Within 6M',
                                       ifelse(tran_1to2_m6to12 == 1, 'Within 12M',
                                              ifelse(tran_1to2_m12to24 == 1, 'Within 24M', 'Never Transitioned')))) %>%
    mutate(Time_Indicator = ifelse(m6_ind == 0, 'Removed After 12M',
                                   ifelse(m12_ind == 0, 'Removed After 6M', 'Used in All Stages')))
  
  drops <- c("APOE4","PTGENDER_Female", 'PTETHCAT_Not.Hisp.Latino', 'PTETHCAT_Hisp.Latino', 'PTRACCAT_White', 'PTRACCAT_Am.Indian.Alaskan', 'PTRACCAT_Asian', 'PTRACCAT_Black', 'PTRACCAT_Hawaiian.Other.PI', 'PTRACCAT_More.than.one', 'PTMARRY_Never.married', 'PTMARRY_Married', 'PTMARRY_Widowed', 'PTMARRY_Divorced', 'tran_1to2_m6', 'tran_1to2_m6to12', 'tran_1to2_m12to24',	'm6_ind', 'm12_ind' )
  data_with_cat_summary= data_with_cat_summary[ , !(names(data_with_cat_summary) %in% drops)]
  return(data_with_cat_summary)
}


# Data no OHE for summary page and eda page
data_with_cat = transform_from_ohe(data_eda)
data_with_cat_summary = transform_from_ohe(data)

# shiny
shinyServer(function(input, output) {
  
  output$inputData <- DT::renderDataTable({
    # round
    round_data_with_cat = round_df(data_with_cat_summary, 3)
    
    output <-
      datatable(
        round_data_with_cat,
        class = 'cell-border stripe',
        rownames = TRUE,
        escape = FALSE,
        options = list(
          scrollX = TRUE,
          lengthChange = FALSE,
          searching = FALSE
        )
      )
  })
  
  
  # Display a data table showing different numeric summary metrics
  output$numericSummary <- renderDataTable({
    numericSummary <- getNumericSummary(data_with_cat_summary)
    output <-
      datatable(
        numericSummary,
        class = 'cell-border stripe',
        options = list(
          paging = FALSE,
          searching = FALSE,
          initComplete = JS(
            "function(settings, json) {",
            "$(this.api().table().header()).css({'background-color': '#000', 'color': '#fff'});",
            "}"
          )
        )
      )
    
  })
  
  output$categoricSummary  <- renderDataTable({
    categoricSummary <- getCategoricSummary(data_with_cat_summary)
    output <-
      datatable(
        categoricSummary,
        class = 'cell-border stripe',
        options = list(
          paging = FALSE,
          searching = FALSE,
          initComplete = JS(
            "function(settings, json) {",
            "$(this.api().table().header()).css({'background-color': '#000', 'color': '#fff'});",
            "}"
          )
        )
      )
    
  })
    
  # calibration plot
  output$Calibration_6 <- renderPlot ({
    predicted = getPredicted(data) 
    
    new_df= cbind(data$tran_1to2_m6,predicted)
    colnames(new_df)[1] = "tran_1to2_m6"
    
    
    new_df %>% mutate(groupi = cut(yhat_TRUE_rf6, seq(0,1,0.05))) %>%
      group_by(groupi) %>% 
      dplyr::summarise(avg_pred_y = mean(yhat_TRUE_rf6), avg_emp_y = mean(tran_1to2_m6)) %>% ungroup() %>%
      ggplot(data = ., aes(x=avg_pred_y,y=avg_emp_y)) + labs(x="Predicted probability", y="Actual probability", title="ICU death") +
      geom_point(color = 'red') + geom_line(color = 'red') + geom_abline(slope=1,intercept=0) + theme_bw() + xlab ("Predicted Probability") +
      ylab ( "Actual Probability") + 
      labs(title = "6 Month Calibration Plot")

    # new_df %>% 
    #  ggplot(aes(x = yhat_TRUE_rf6, y = tran_1to2_m6)) +
    #   scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2)) +
    #   scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2)) +
    #   geom_smooth(aes(x = yhat_TRUE_rf6, y = tran_1to2_m6), color = "red", se = F, method = "loess") +
    #   geom_abline() +
    #   xlab ("Predicted Probability") +
    #   ylab ( "Actual Probability") + 
    #   labs(title = "6 Month Calibration Plot") +
    #   theme_light()
    
    })
    
    output$Calibration_12 <- renderPlot ({
      predicted = getPredicted(data) 
      new_df= cbind(data$tran_1to2_m6to12,predicted)
      colnames(new_df)[1] = "tran_1to2_m6to12"
      
      
     new_df %>% mutate(groupi = cut(yhat_TRUE_rf12, seq(0,1,0.05))) %>%
        group_by(groupi) %>% 
        dplyr::summarise(avg_pred_y = mean(yhat_TRUE_rf12), avg_emp_y = mean(tran_1to2_m6to12)) %>% ungroup() %>%
        ggplot(data = ., aes(x=avg_pred_y,y=avg_emp_y)) + labs(x="Predicted probability", y="Actual probability", title="ICU death") +
        geom_point(color = 'red') + geom_line(color = 'red') + geom_abline(slope=1,intercept=0) + theme_bw() + xlab ("Predicted Probability") +
        ylab ( "Actual Probability") + 
        labs(title = "12 Month Calibration Plot")
      
      
      # new_df %>% 
      # 
      #   ggplot(aes(x = yhat_TRUE_rf12, y = tran_1to2_m6to12)) +
      #   scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2)) +
      #   scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2)) +
      #   geom_smooth(aes(x = yhat_TRUE_rf12, y = tran_1to2_m6to12), color = "red", se = F, method = "loess") +
      #   geom_abline() +
      #   xlab ("Predicted Probability") +
      #   ylab ( "Actual Probability") + 
      #   labs(title = "12 Month Calibration Plot") +
      #   theme_light()
    })
      
    output$Calibration_24 <- renderPlot ({
      predicted = getPredicted(data) 
      
      new_df= cbind(data$tran_1to2_m12to24,predicted)
      colnames(new_df)[1] = "tran_1to2_m12to24"
      
     new_df %>% mutate(groupi = cut(yhat_TRUE_rf24, seq(0,1,0.05))) %>%
        group_by(groupi) %>% 
        dplyr::summarise(avg_pred_y = mean(yhat_TRUE_rf24), avg_emp_y = mean(tran_1to2_m12to24)) %>% ungroup() %>%
        ggplot(data = ., aes(x=avg_pred_y,y=avg_emp_y)) + labs(x="Predicted probability", y="Actual probability", title="ICU death") +
        geom_point(color = 'red') + geom_line(color = 'red') + geom_abline(slope=1,intercept=0) + theme_bw() + xlab ("Predicted Probability") +
        ylab ( "Actual Probability") + 
        labs(title = "24 Month Calibration Plot")
      

      # new_df %>%
      #   ggplot(aes(x = yhat_TRUE_rf24, y = tran_1to2_m12to24)) +
      #   scale_y_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2)) +
      #   scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, by = 0.2)) +
      #   geom_smooth(aes(x = yhat_TRUE_rf24, y = tran_1to2_m12to24), color = "red", se = F, method = "loess") +
      #   geom_abline() +
      #   xlab ("Predicted Probability") +
      #   ylab ( "Actual Probability") +
      #   labs(title = "24 Month Calibration Plot") +
      #   theme_light()
  })
  
  
  # get user uploaded data
  getNewData <- reactive({
    if (is.null(input$fileInput)) {
      return(NULL)
    }
    newFile <- input$fileInput
    newData <-
      read.csv(newFile$datapath, stringsAsFactors = TRUE)
    newData
  })
  
  

  # *for testing remove in final version
  # view user input data
  # output$newData <- DT::renderDataTable({
  #   new_data = getNewData()
  #   output <-
  #     datatable(
  #       new_data,
  #       class = 'cell-border stripe',
  #       rownames = TRUE,
  #       escape = FALSE,
  #       options = list(
  #         scrollX = TRUE,
  #         lengthChange = FALSE,
  #         searching = FALSE
  #       )
  #     )
  # })
  
  #################################################
  ################ EDA page #######################
  # get a new data containing all patients' last diagnosis codes
  getLastDiagnosisData <- function (data_eda, data_full){
    last.adni = data_full %>% filter(RID %in% data_eda$RID) %>% ddply(.(RID), tail,1)
    last.adni.df = data_eda %>% mutate(DX_last=as.factor(last.adni$DX))
    last.adni.df = last.adni.df %>%  mutate(DX_lst= ifelse(DX_last==0, "CN", "MCI")) %>% 
      mutate(DX_lst=ifelse(DX_last==2, "AD", DX_lst)) %>% 
      mutate(DX_lst=as.factor(DX_lst))
    eda.data <<- last.adni.df
  }
  
  getLastDiagnosisData(data_eda, data_full)

  # filter numeric columns as a dataset
  getNumericData <- function (eda.data){
    num.data = eda.data %>% 
      select(ends_with("_bl")) %>% select(-c("Years_bl","Month_bl"))
    num.data
  }

  # filter categorical columns as a dataset
  getCategoricalData <- function (data_with_cat){
    cat.data = join(data_with_cat, eda.data, by="RID") %>% 
      select("APOE4_Allele", "Gender", "Ethnicity","Race","Marital_Status")
    cat.data
  }
  
  output$select_numerical_attribute <- renderUI ({
    selectizeInput(
      "num_attributes",
      "Select attributes", 
      choices = c("choose" = "", colnames(getNumericData(eda.data)))
    )
  })
  
  output$select_categorical_attribute <- renderUI ({
    selectizeInput(
      "cat_attributes",
      "Select attributes",
      choices = c("choose" = "", colnames(getCategoricalData(data_with_cat)))
    )
  })
  
  # filter the dataset with only the "DX_lst" and the attribute column
  attribute_filter_num <- reactive ({
    select.attri = eda.data %>% select("DX_lst", input$num_attributes)
    select.attri
  })
  
  attribute_filter_cat <- reactive ({
    select.attri = join(data_with_cat, eda.data, by="RID") %>% select("DX_lst", input$cat_attributes)
    select.attri
  })

  
  output$numeric_edaplot <- renderPlot ({
    # new.data = getNewData()
    new.data = new_data_raw
    plot.data = attribute_filter_num()
    
    ggplot() + geom_density(data=plot.data, aes_string(x=colnames(plot.data)[2], group="DX_lst", fill="DX_lst"),
                            adjust=1.5, alpha=.4)  +   
    geom_label(data=new.data[1,],  aes_string(x=colnames(plot.data)[2], y=0, label="1"), colour="red",size = 3,alpha=0.7) + 
    geom_label(data=new.data[2,],  aes_string(x=colnames(plot.data)[2], y=0, label="2"), colour="blue",size = 2,alpha=0.7) + 
    geom_label(data=new.data[3,],  aes_string(x=colnames(plot.data)[2], y=0, label="3"), colour="green",size = 1,alpha=0.7) +
    theme_light()
  })
  

  
  output$categorical_edaplot <- renderPlot ({
    new.data = getNewData()
    
    data_with_cat2 = new.data %>% 
      mutate(APOE4_Allele = ifelse(APOE4 == 0, '0 Allele',
                                   ifelse(APOE4 == 1, '1 Allele', '2 Allele'))) %>%
      mutate(Gender = ifelse(PTGENDER_Female == 1, "F", "M")) %>%
      mutate(Ethnicity = ifelse(PTETHCAT_Not.Hisp.Latino == 1, "Not Hispanic", "Hispanic")) %>%
      mutate(Race = ifelse(PTRACCAT_White == 1, "White",
                           ifelse(PTRACCAT_Am.Indian.Alaskan == 1, "Native American",
                                  ifelse(PTRACCAT_Asian == 1, "Asian",
                                         ifelse(PTRACCAT_Black == 1, "Black",
                                                ifelse(PTRACCAT_Hawaiian.Other.PI == 1, "Hawaiian/PI", "Multi-racial")))))) %>%
      mutate(Marital_Status = ifelse(PTMARRY_Never.married == 1, "Never Married",
                                     ifelse(PTMARRY_Married == 1, "Married",
                                            ifelse(PTMARRY_Widowed == 1, "Widowed", "Divorced"))))
    
    drops <- c( "APOE4","PTGENDER_Female", 'PTETHCAT_Not.Hisp.Latino', 'PTETHCAT_Hisp.Latino', 'PTRACCAT_White', 'PTRACCAT_Am.Indian.Alaskan', 'PTRACCAT_Asian', 'PTRACCAT_Black', 'PTRACCAT_Hawaiian.Other.PI', 'PTRACCAT_More.than.one', 'PTMARRY_Never.married', 'PTMARRY_Married', 'PTMARRY_Widowed', 'PTMARRY_Divorced', 'tran_1to2_m6', 'tran_1to2_m6to12', 'tran_1to2_m12to24',	'm6_ind', 'm12_ind' )
    data_with_cat2= data_with_cat2[ , !(names(data_with_cat2) %in% drops)]
    
    plot.data = attribute_filter_cat()

   ggplot() + geom_bar(data=plot.data, aes_string(x=colnames(plot.data)[2], group="DX_lst", fill="DX_lst"), alpha=0.4) +
     geom_label(data=data_with_cat2[1,],  aes_string(x=colnames(plot.data)[2], y=0,label='1'), colour="red",size = 3,alpha=0.7) +
     geom_label(data=data_with_cat2[2,],  aes_string(x=colnames(plot.data)[2], y=0,label='2'), colour="blue",size = 2,alpha=0.7) +
     geom_label(data=data_with_cat2[3,],  aes_string(x=colnames(plot.data)[2], y=0,label='3'), colour="green",size = 1,alpha=0.7) +
     theme_light() 
     
    
  })

  
  #################################################
  
  # check predicted output for three patients
  output$predTable <- DT::renderDataTable({
    new_data = getNewData()
    predicted = getPredicted(new_data)
    
    useful_attr = c('Attributes','yhat_TRUE_rf6', 'yhat_TRUE_rf12', 'yhat_TRUE_rf24' )
    predicted = predicted[useful_attr]
    colnames(predicted) <- c("Patient", "Transtion Prob 6M", "Transtion Prob 12M", "Transtion Prob 24M")
    
    output <- datatable(
      predicted,
      class = 'cell-border stripe',
      rownames = TRUE,
      escape = FALSE,
      options = list(
        scrollX = TRUE,
        lengthChange = FALSE,
        searching = FALSE
      )
    )
  })

  
  # risk stratification plot, 6, 12, 24m
  output$RiskStratification_6 <- renderPlot ({
    new_data = getNewData()
    new_data$Patient_Index = c(1:nrow(new_data))
    new_data$Patient_Index = as.factor(new_data$Patient_Index)
    
    
    
    
    predicted = getPredicted(data) %>% mutate( bin=cut_width(yhat_TRUE_rf6, width=0.05, boundary=0) )
    
    new_points_predicted = cbind(new_data$Patient_Index, getPredicted(new_data) %>% mutate( bin=cut_width(yhat_TRUE_rf6, width=0.05, boundary=0) ))
    colnames(new_points_predicted)[1] = "Patient_Index"
    
    #predicted$bin = factor(predicted$bin, levels = c("[0,0.1]"  , "(0.1,0.2]" ,"(0.2,0.3]", "(0.3,0.4]" ,"(0.4,0.5]", "(0.5,0.6]",
    #"(0.6,0.7]", "(0.7,0.8]", "(0.8,0.9]" ,"(0.9,1]"))
    
    ggplot(predicted, aes(x= bin )) + 
      geom_bar(fill = 'blue', alpha=0.3)+ 
      theme(axis.text.x = element_text(angle = 45, vjust = 0.5, hjust=0.5)) + 
      labs(title = "6 Month Early Prediction Risk Stratification ",color = "Patient") + 
      xlab("Transition Probability") +
      ylab("Patient Count") +
      scale_x_discrete(drop=FALSE) +
      geom_label(data=new_points_predicted, aes(x= bin, y= 0, label=Patient_Index, colour = Patient_Index),position=position_jitter(h=0.5,w=0.7)) +
      theme_light()+
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
    
  })
  
  output$RiskStratification_12 <- renderPlot ({
    new_data = getNewData()
    new_data$Patient_Index = c(1:nrow(new_data))
    new_data$Patient_Index = as.factor(new_data$Patient_Index)
    
    predicted = getPredicted(data) %>% mutate( bin=cut_width(yhat_TRUE_rf12, width=0.05, boundary=0) )
    
    new_points_predicted = cbind(new_data$Patient_Index, getPredicted(new_data) %>% mutate( bin=cut_width(yhat_TRUE_rf12, width=0.05, boundary=0) ))
    colnames(new_points_predicted)[1] = "Patient_Index"
    
    ggplot(predicted, aes(x= bin)) + 
      geom_bar(fill = 'blue', alpha=0.3)+ 
      theme(axis.text.x = element_text(angle = 45, vjust = 0.5, hjust=0.5)) + 
      labs(title = "12 Month Early Prediction Risk Stratification ",color = "Patient") + 
      xlab("MCI to AD Transition Probability") +
      ylab("Patient Count") +
      geom_label(data=new_points_predicted, aes(x= bin, y= 0, label=Patient_Index, colour = Patient_Index),position=position_jitter(h=0.5,w=0.5)) +
      theme_light() +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
    
  })
  
  
  output$RiskStratification_24 <- renderPlot ({
    new_data = getNewData()
    new_data$Patient_Index = c(1:nrow(new_data))
    new_data$Patient_Index = as.factor(new_data$Patient_Index)
    
    predicted = getPredicted(data) %>% mutate( bin=cut_width(yhat_TRUE_rf24, width=0.05, boundary=0) )

    new_points_predicted = cbind(new_data$Patient_Index, getPredicted(new_data) %>% mutate( bin=cut_width(yhat_TRUE_rf24, width=0.05, boundary=0) ))
    colnames(new_points_predicted)[1] = "Patient_Index"
    
    ggplot(predicted, aes(x= bin)) + 
      geom_bar(fill = 'blue', alpha=0.3)+ 
      theme(axis.text.x = element_text(angle = 45, vjust = 0.5, hjust=0.5)) + 
      labs(title = "24 Month Early Prediction Risk Stratification ",color = "Patient") + 
      xlab("MCI to AD Transition Probability") +
      ylab("Patient Count") +
      geom_label(data=new_points_predicted, aes(x= bin, y= 0, label=Patient_Index, colour = Patient_Index),position=position_jitter(h=0.5,w=0.5)) + 
      theme_light() +
      theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
  })
  
  
  # risk over time plot
  output$RiskOverTime <- renderPlot ({
    new_data = getNewData()
    new_data <- tibble::rowid_to_column(new_data, "Patient_Index")
    
    
    predicted = getPredicted(data)
    new_points_predicted = getPredicted(new_data)
    transformed_data = stack(predicted[,c('yhat_TRUE_rf6','yhat_TRUE_rf12','yhat_TRUE_rf24')] )
    transformed_new_data = cbind(new_data$Patient_Index,stack(new_points_predicted[,c('yhat_TRUE_rf6','yhat_TRUE_rf12','yhat_TRUE_rf24')]))
    colnames(transformed_new_data)[1] <- "Patient_Index"
    
    
    ggplot(data = transformed_data,aes(y = values , x = ind)) + 
          geom_boxplot() +
            xlab ("Final Stage") +
            ylab ( "MCI to AD Transition Probability") + 
            labs(title = "Risk Over Time",color = "Patient") + 
       scale_x_discrete(breaks = c('yhat_TRUE_rf6','yhat_TRUE_rf12','yhat_TRUE_rf24'), labels=c("6 month","12 month","24 month")) +
    
      geom_label(data=transformed_new_data, aes(x= ind, y= values, label=Patient_Index, colour = factor(Patient_Index))) +
      
      theme_light()
  })
  
  
  # helpers
  # numeric summary
  getNumericSummary <- function(data) {
    col.type <- as.character(sapply(data, is.numeric))
    numeric.data <-
      subset(data, select = which(col.type == "TRUE"))
    col.missing <-
      as.numeric(sapply(numeric.data, function(x) {
        sum(is.na(x))
      }))
    col.mean <- round(as.numeric(sapply(numeric.data, mean)), 2)
    col.median <- round(as.numeric(sapply(numeric.data, median)), 2)
    col.mode <-
      round(as.numeric(sapply(numeric.data, function(x) {
        getMode(x)
      })), 2)
    col.sd <- round(as.numeric(sapply(numeric.data, sd)), 2)
    col.min <- round(as.numeric(sapply(numeric.data, min)), 2)
    col.max <- round(as.numeric(sapply(numeric.data, max)), 2)
    numeric.summary <-
      data.frame(
        colnames(numeric.data),
        col.missing,
        col.mean,
        col.median,
        col.mode,
        col.sd,
        col.min,
        col.max
      )
    colnames(numeric.summary) <-
      c("Attribute",
        "Missing",
        "Mean",
        "Median",
        "Mode",
        "SDev",
        "Min",
        "Max")
    return(numeric.summary)
  }
  
  # get mode of list
  getMode <- function(v) {
    uniqv <- unique(v)
    uniqv[which.max(tabulate(match(v, uniqv)))]
  }
  
  # get categorical summary
  getCategoricSummary <- function(data) {
    col.type <- as.character(sapply(data, is.numeric))
    categoric.data <-
      subset(data, select = which(col.type == "FALSE"))
    col.missing <-
      as.numeric(sapply(categoric.data, function(x) {
        sum(is.na(x))
      }))
    col.levels <-
      as.numeric(sapply(categoric.data, function(x) {
        length(unique(x))
      }))
    mcv.count <- as.character(sapply(categoric.data, function(x) {
      cat.combined <- character()
      cat.count <- data.frame(table(x))
      cat.prop <- data.frame(prop.table(table(x)) * 100)
      cat.prop[, 2] <- round(cat.prop[, 2], 2)
      cat.count <-
        cat.count[order(cat.count[, 2], decreasing = TRUE),]
      cat.prop <-
        cat.prop[order(cat.prop[, 2], decreasing = TRUE),]
      cat.combined <-
        c(cat.combined,
          paste(cat.count[, 1], ": ", cat.count[, 2], "[", cat.prop[, 2], "%]", sep =
                  ""))
      return(toString(cat.combined))
    }))
    categoric.summary <-
      data.frame(colnames(categoric.data),
                 col.missing,
                 col.levels,
                 mcv.count)
    colnames(categoric.summary) <-
      c("Attribute", "Missing", "Levels", "Distribution")
    return(categoric.summary)
  }
  
  
  # prediction model
  getPredicted <- function(data){
    predicted_rf6 <- predict(rf6, data, type = 'prob')
    predicted_rf12 <- predict(rf12, data, type = 'prob')
    predicted_rf24 <- predict(rf24, data, type = 'prob')
    
    predictions_rf <- 
      
        data.frame(
        cbind(c('Patient 1',
                'Patient 2',
                'Patient 3'),
              predicted_rf6,predicted_rf12,predicted_rf24)
        )
      
    names(predictions_rf) <- c(
      "Attributes",
      "yhat_TRUE_rf6",
      "yhat_FALSE_rf6",
      "yhat_TRUE_rf12",
      "yhat_FALSE_rf12",
      "yhat_TRUE_rf24",
      "yhat_FALSE_rf24"
    )
    return(predictions_rf)
  }

  # round
  round_df <- function(df, digits) {
    nums <- vapply(df, is.numeric, FUN.VALUE = logical(1))
    
    df[,nums] <- round(df[,nums], digits = digits)
    
    (df)
  }
        
})