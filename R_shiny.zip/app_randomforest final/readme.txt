#readme
open server 
Run the whole file
import new_patients.csv under new patient section