library(shiny)
library(shinydashboard)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(plotly)
library(DT)
library(plyr)
library(rpart)

header <- dashboardHeader (title = "AD Predictor")

sidebar <-dashboardSidebar (
  sidebarMenu (
    id = "tabs",
    menuItem("Introduction", tabName = "introduction"),
    menuItem("View Database", tabName = "viewData"),
    menuItem("Summary Statistics", tabName = "summaryStatistics"),
    menuItem("Calibration Plot", tabName = "calibration"),
    br(),
    br(),
    menuItem(HTML(paste(tags$span(style="color:red", "*"), tags$span(style="color:white","Below is new patient data")))),
    menuItem("Upload Patient Data", tabName = "upload"),
    #menuItem("View Upload", tabName = "viewNew"),
    menuItem("Exploratory Analysis", tabName = "exploratoryAnalysis"),
    menuItem("View Predicted", tabName = "viewPred"),
    menuItem("Risk Stratification ", tabName = "riskStratification"),
    menuItem("Risk Over Time", tabName = "riskOverTime")
  )
)

body <- dashboardBody (

  tabItems(
    tabItem(
      tabName = "introduction",
      fluidRow(
        tags$style(HTML("body {background-image: url('ad.jpg');}")),
        box(
          width = 12,
          solidHeader = TRUE,
          h2("Introduction", align = "center")
        ),
        box(
          width = 12,
          solidHeader = TRUE,
          br(),
          br(),
          style = "background-image: url('ad.jpg');",
          style = "background-repeat: no-repeat;",
          style = "background-size: 100%",
          box(
            width = 12,
            solidHeader = TRUE,
            p(
              " The goal of this AD Predictor is to help physicians understand MCI patients' predicted risks of transition to AD within 6, 12 and 24 months after the initial visit. 
              Utilizing existing data uploaded to ADNI, which contains over 600 patients, we allow users to explore how a new patient's risk variables (including biomarker, cognitive, demogarphic and imaging data)
              as well as his/her probability of tranisitioning to AD compare with our base popuplation that is used to build our machine learning model.
            ",
              align = "justify",
              style = "font-size : 14pt"
            )
          ),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br(),
          br()
        )
      )
    ),
    
    
    tabItem(tabName = "viewData",
          fluidRow (
            box(
              width = 12,
              solidHeader = TRUE,
              h2("View Existing Database")
            )
          ),
          fluidRow(
            box(
              width = 12,
              dataTableOutput('inputData')
            ))),
  
    tabItem(tabName = "summaryStatistics",
            fluidRow (
              box(
                width = 12,
                solidHeader = TRUE,
                h2("View Existing Summary Statistics"))),
                
                fluidRow(
                  box(
                    width = 12,
                    solidHeader = TRUE,
                    #column(width = 12,solidHeader = TRUE,
                    #DT::dataTableOutput('dataSummary')
                    tabsetPanel(
                      tabPanel(
                        h4("Numerical Attributes"),
                        br(),
                        dataTableOutput("numericSummary")
                        ),
                      tabPanel(
                        h4("Categorical Attributes"),
                        br(),
                        dataTableOutput("categoricSummary")
                      ))
                  ))),
    
    
    tabItem(tabName = "calibration",
            fluidRow (
              box(
                width = 12,
                solidHeader = TRUE,
                h2("Are the predicted results reliable comparing to empirical circumstance?")
              )
            ),
            fluidRow(
              box(plotOutput("Calibration_6"),
                  width = 12
                  
              )),
            fluidRow(
              box(plotOutput("Calibration_12"),
                  width = 12
                  
              )),
            fluidRow(
              box(plotOutput("Calibration_24"),
                  width = 12
                  
              ))
            
    ),
    
    tabItem(tabName = "upload",
            fluidRow(
              box(
                width = 12,
                solidHeader = TRUE,
                column(12, h2("Load the dataset"), align = "center"),
                column(12, h4("(Please upload a csv file following the format of our existing database)"), align =
                         "center")
              )
            ),
            fluidRow(box(
              solidHeader = TRUE,
              width = 12,
              column(12, fileInput(
                'fileInput', h4('Upload File'), accept = c('.csv')
              ), align = "center")
            ))),
    
    
    # # for testing, remove in final version
    # tabItem(tabName = "viewNew",
    #         fluidRow (
    #           box(
    #             width = 12,
    #             solidHeader = TRUE,
    #             h2("View New Data")
    #           )
    #         ),
    #         fluidRow(
    #           box(
    #             width = 12,
    #             dataTableOutput('newData')
    #           ))),
    #   
    
    
    tabItem(tabName = "exploratoryAnalysis",
            fluidRow (
              box(
                width = 12,
                solidHeader = TRUE,
                h2("How Does Your Patient's Risk Compare with Others?")
              )),
            fluidRow(
              box(
                width = 12,
                solidHeader = TRUE,
                tabsetPanel(
                  tabPanel(
                    
                    h4("Numeric attributes", align = "center"),
                    br(),
                    sidebarPanel(uiOutput("select_numerical_attribute")),
                    plotOutput("numeric_edaplot"),
                    width = 5.5
                    
                  ),
                  tabPanel(

                    h4("Categorical attributes", align = "center"),
                    br(),
                    sidebarPanel(uiOutput("select_categorical_attribute")),
                    plotOutput("categorical_edaplot"),
                    width = 5.5

                  )
                ),
                br(),
                br(), 
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br(),
                br()
              )
            )),


    
    #         
            # fluidRow(
            #   box(
            #     width = 12,
            #     solidHeader = TRUE,
            #     tabsetPanel(
            #       tabPanel(
            #         h4("Numeric attributes", align = "center"),
            #         br(),
            #         sidebarPanel(
            #           uiOutput("select_numerical_attribute")),
            #         plotOutput("numeric_edaplot"),
            #         width = 5.5
            #       ),
            #       tabPanel(
            #         h4("Categorical attributes", align = "center"),
            #         br(),
            #         sidebarPanel(
            #           uiOutput("select_categorical_attribute")),
            #         plotOutput("numeric_edaplot"),
            #         width = 5.5
            #       ))
            #   )
            # )),
    
    # # for testing, remove in final version
    tabItem(tabName = "viewPred",
             fluidRow (
               box(
                 width = 12,
                 solidHeader = TRUE,
                 h2("View Predicted Result of Sample Patients")
               )
             ),
             fluidRow(
               box(
                 width = 12,
                 dataTableOutput('predTable')
               ))),


    
    
    tabItem(tabName = "riskStratification",
            fluidRow (
              box(
                width = 12,
                solidHeader = TRUE,
                h2("What Risk Group Does Your Patient Belong to?")
              )
            ),
            fluidRow(
              box(plotOutput("RiskStratification_6"),
                  width = 12
                  
              )),
            fluidRow(
              box(plotOutput("RiskStratification_12"),
                  width = 12
                  
              )),
            fluidRow(
              box(plotOutput("RiskStratification_24"),
                  width = 12
                  
              ))
  
    ),
    
    tabItem(tabName = "riskOverTime",
            fluidRow (
              box(
                width = 12,
                solidHeader = TRUE,
                h2("When and Will Your Patient Transition to AD?")
              )
              
            ),
            
            fluidRow(
              box(plotOutput("RiskOverTime"),
                  width = 12
              )
    )
  )))

ui <- dashboardPage(header, sidebar, body, skin = "red")